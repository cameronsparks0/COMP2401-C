Name: Cameron Sparks
Student Number: 101181932
Source Files: hello.c, tw1.c, tw2.c, tw3.c, tw4.c
Instructions For Compiling Source Files: Type  gcc -o outputFileName sourceFileName
Instructions for running files: Type outputFileName 
