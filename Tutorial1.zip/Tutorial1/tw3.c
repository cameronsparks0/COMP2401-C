// tw3.cpp : correct the errors/warning in the file.  



#include "stdio.h"

int main(int argc, char* argv[])
{
 int x=3;

 printf("x*x =%d\n",x*x);

 return 0;
}


