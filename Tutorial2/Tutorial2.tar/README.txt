Name: Cameron Sparks
Student Number: 101181932
Source Files: printTriangles.c
Instructions for compiling: gcc -o {filename} {printTriangles.c}