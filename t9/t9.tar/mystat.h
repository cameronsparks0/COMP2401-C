
// FILE mystat.h

#ifndef HEADER_MYSTAT
#define HEADER_MYSTAT

void average(float *arr, int size, float *average);

#endif
